import React, { useState } from "react";
import './main.css';
import Cards from "../cards/cards";
import {objJson,objTitle} from "../source/api";


export default function Main ({state}){
    const [changerView, setChangerView] = useState('json')
    const [mainTitle, SetmainTitle] = useState('json')

    state.changerView = setChangerView
    state.mainTitle = SetmainTitle


    return <main>
        <h1 className="main_title">{objTitle[mainTitle]}</h1>
        <div className="main_container">
            {objJson[changerView].map((item,index) => <Cards data = {item} key={index}/>)}
        </div>
    </main>
    
}

