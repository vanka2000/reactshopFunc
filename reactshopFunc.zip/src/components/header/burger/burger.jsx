import React, { useState } from "react";
import './burger.css';

export default function Burger ({className, state}){

    const [ulMenu, setUlMenu] = useState({man : 'no-visible', woman : 'no-visible'})
    
    function showMenu(){
        setUlMenu({ man : '',  woman : 'no-visible'})
    }

    function noShowMenu(){
        setUlMenu({ man : 'no-visible',  woman : 'no-visible' })
    }

    function getCards(e){
        state.changerView(e.target.dataset.cloth)
        state.mainTitle(e.target.dataset.cloth)
    }
        return (
            <section className={`burger ${className.openBurger}`}>
                <div className="burger_cont">
                    <div 
                    onMouseOver={showMenu} 
                    onMouseOut={noShowMenu} 
                    className="burger_headname">Мужчинам
                        <ul className={`ul ${ulMenu.man}`}> 
                            <li onClick={getCards} data-cloth ='jsonManKurtki' href="#">Верхняя одежда</li>
                            <li onClick={getCards} data-cloth ='jsonManShoes' href="#">Обувь</li>
                            <li onClick={getCards} data-cloth ='jsonManSportWear' href="#">Спорт одежда</li>
                            <li onClick={getCards} data-cloth ='jsonManHomeWear' href="#">Домашняя одежда</li>
                        </ul>
                    </div>
                </div>
                <div className="burger_cont">
                <div 
                // onMouseOver={showMenu}
                // onMouseOut={noShowMenu}
                className="burger_headname">Женщинам
                        <ul className={`ul ${ulMenu.woman}`}> 
                            <li>Верхняя одежда</li>
                            <li>Обувь</li>
                            <li>Спорт одежда</li>
                            <li>Куртки</li>
                        </ul>
                    </div>
                </div>
            </section>
        )
    }
