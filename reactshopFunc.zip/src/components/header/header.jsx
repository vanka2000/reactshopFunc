
import React, { useEffect, useState } from 'react';
import './header.css'
import Burger from './burger/burger';

function Header ({state}){
    const [visible, setVisible] = useState({searchState : 'no-visible', openBurger : 'no-visible'})
    
    function mouseOutHeader(){                                     //- метод , скрывает наш инпут в хедере
        setVisible(visible.searchState === 'no-visible' 
            ? {searchState : '', openBurger : ''} 
            : {searchState : 'no-visible', openBurger : 'no-visible'})         
    }

    return <header  className='header' >               
        <div onClick={mouseOutHeader} className='header-conteiner'>
            <span className='line'></span>
            <span className='line'></span>
            <span className='line'></span>
        </div>
        <Burger className={visible} state={state}/>
        <a href='main' className='logo'>МОЁ</a>
        <div className={`header-conteiner-last ${visible.searchState}`}>
            <input className='input_search'/>
            <button className='btn-search'>Найти</button>
        </div>
    </header>
}


 export default Header