import React from 'react';
import './App.css';
// import getData from './source/api';
import Header from './header/header';
import Main from './main/main';

function App () {

   const setState = {}

   return <>
      <Header state={setState}/>
      <Main state={setState}/>
   </>
 
}




export default App;
