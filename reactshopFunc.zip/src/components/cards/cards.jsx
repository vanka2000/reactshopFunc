import React from "react";
import './cards.css';


function Cards ({data}){
 
    return  <div className="main_card">
        <div className="main_card_img" style={{backgroundImage: `url(${data.img})`}}></div>
        <div className="main_card_container">
            <p className="main_card_price">{data.price}p.</p>
            <p className="main_card_title">{data.name}</p>
            <button className="main_card_buy">Add to basket</button>
        </div>
       
    </div>
    
}
export default Cards;
